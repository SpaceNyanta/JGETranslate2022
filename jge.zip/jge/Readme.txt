C:\Program Files (x86)\Steam\steamapps\common\Granado Espada Japan\ge


Dictionary.ipf is the translation